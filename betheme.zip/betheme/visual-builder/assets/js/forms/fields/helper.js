function mfn_field_helper(field) {
	return `<div class="mfn-help-info"><a href="${field.link}" target="_blank"><span class="mfn-icon mfn-icon-desc"></span>${field.title}</a></div>`;
}