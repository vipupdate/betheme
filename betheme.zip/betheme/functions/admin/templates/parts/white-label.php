<?php
if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}
?>

<div id="mfn-dashboard" class="wrap about-wrap">
	<?php _e( 'This feature is disabled in White Label mode.', 'mfn-opts' );?>
</div>